# STOCK MARKET PRICE FORECASTING API
Contains the FastAPI files for the setup of the restfulAPI