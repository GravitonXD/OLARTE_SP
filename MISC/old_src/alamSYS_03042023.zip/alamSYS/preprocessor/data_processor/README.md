# Stock Price Forecasting Model (SPFM)
First Initialization