# About this directory
Pickle file of the model is stored here.